#!/usr/bin/env bash

EXP_ID_BASE='test_FEMNIST_fiame_lr'
DATASET='FEMNIST'
# LEARNING_RATE=0.003
NUM_ROUND=200
BATCH_SIZE=10
NUM_EPOCH=20
CLIENT_PER_ROUND=-1
MODEL='ann'

cd ../

CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
# fedadmm
# for LEARNING_RATE in 0.012 0.014 0.016 0.02
for LEARNING_RATE in 0.012
do
    EXP_ID=$EXP_ID_BASE$LEARNING_RATE
    python3  -u main.py --dataset=$DATASET --optimizer='fiame' --exp_id=$EXP_ID  \
                --learning_rate=$LEARNING_RATE --num_rounds=$NUM_ROUND \
                --clients_per_round=$CLIENT_PER_ROUND --eval_every=1 \
                --batch_size=$BATCH_SIZE --num_epochs=$NUM_EPOCH --model=$MODEL
done