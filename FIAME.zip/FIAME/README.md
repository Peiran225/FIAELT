# FIAME

## Introduction

This package is the implementation of FIAME algorithm.
We will make the whole repo public when the paper is accepted.


## Code Usage

cd run_script/
sh run_different_lr.sh